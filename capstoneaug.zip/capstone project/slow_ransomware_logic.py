import math
from collections import Counter

def calculate_file_entropy(filepath, chunk_size=8192):
    """
    Calculates the Shannon entropy of a file block to detect encryption.
    A value close to 8.0 strongly suggests the data is encrypted.
    """
    try:
        with open(filepath, 'rb') as f:
            data = f.read(chunk_size)
            
        if not data:
            return 0.0
            
        entropy = 0
        length = len(data)
        frequencies = Counter(data)
        
        for count in frequencies.values():
            probability = count / length
            entropy -= probability * math.log2(probability)
            
        return entropy
    except Exception as e:
        return 0.0

def detect_slow_ransomware_io(io_history_window, tolerance=0.15):
    """
    Analyzes a sliding window of I/O operations.
    If the total Read/Write bytes are nearly 1:1 over time, it indicates slow 
    encryption (reading original file -> encrypting -> writing back to disk).
    
    io_history_window format: [{'read_bytes': 1024, 'write_bytes': 1048}, ...]
    """
    total_read = sum(entry.get('read_bytes', 0) for entry in io_history_window)
    total_write = sum(entry.get('write_bytes', 0) for entry in io_history_window)
    
    # Avoid division by zero
    if total_write == 0 or total_read == 0:
        return False
        
    ratio = total_read / total_write
    
    # Alert if ratio is approximately 1.0 (within our tolerance)
    is_suspicious_ratio = (1.0 - tolerance) <= ratio <= (1.0 + tolerance)
    
    return is_suspicious_ratio
