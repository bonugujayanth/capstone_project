import sys
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# CONFIGURATION
FEATURES = ['CPU_Usage', 'Read_Delta', 'Write_Delta']  # must match train_standard.py / implementation.py
DEFAULT_INPUT = os.path.join(os.path.dirname(__file__), "datasets", "benign_extended_updated.csv")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "isolation_forest_model.pkl")
PERCENTILE = 97  # threshold = this percentile of anomaly scores on held-out normal data (95-99 range)
CONTAMINATION = 0.03  # matches ~97th percentile assumption


def load_normal_telemetry(path):
    df = pd.read_csv(path, on_bad_lines='skip', comment='#')
    if 'Label' in df.columns:
        df = df[df['Label'] == 0]
    for col in FEATURES:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.dropna(subset=FEATURES).reset_index(drop=True)
    return df


def train(input_path=DEFAULT_INPUT, model_path=MODEL_PATH, percentile=PERCENTILE):
    print(f"Loading normal telemetry from {input_path}...")
    df = load_normal_telemetry(input_path)
    print(f"{len(df)} benign rows loaded.")

    train_df, val_df = train_test_split(df, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(train_df[FEATURES])

    print("Training IsolationForest on normal data only...")
    model = IsolationForest(
        n_estimators=200,
        contamination=CONTAMINATION,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train)

    # Higher = more anomalous (sklearn's score_samples is the opposite: higher = more normal)
    X_val = scaler.transform(val_df[FEATURES])
    val_anomaly_scores = -model.score_samples(X_val)

    threshold = float(np.percentile(val_anomaly_scores, percentile))

    print(f"Held-out normal anomaly scores: mean={val_anomaly_scores.mean():.4f}, "
          f"std={val_anomaly_scores.std():.4f}")
    print(f"Chosen threshold (P{percentile} of held-out normal scores): {threshold:.4f}")
    print(f"-> Copy this value into ISO_THRESHOLD in implementation.py if it differs from the current constant.")

    bundle = {
        'model': model,
        'scaler': scaler,
        'threshold': threshold,
        'features': FEATURES,
        'percentile': percentile,
    }
    joblib.dump(bundle, model_path)
    print(f"Saved model + scaler + threshold to {model_path}")
    return threshold


if __name__ == "__main__":
    input_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_INPUT
    train(input_path=input_path)
