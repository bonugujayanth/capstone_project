import libvirt
import time
import pandas as pd
import sys
import os

# CONFIGURATION
# Based on your virsh list, the running name is "vm-1"
VM_NAME = "victim-vm" 
OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "datatemp.csv")
LABEL_VALUE = 1

def get_mgmt_alert():
    log_paths = [
        "/var/log/libvirt/qemu/victim-vm.log",
        os.path.expanduser("~/.local/share/libvirt/qemu/log/victim-vm.log"),
    ]

    risk_keywords = [
        "device_del",
        "snapshot-delete",
        "set_password",
        "drive-del",
        "blockdev-del",
        "netdev_del",
        "block-job-cancel",
        "block-job-pause",
        "send-key",
    ]

    for log_path in log_paths:
        if not os.path.exists(log_path):
            continue
        try:
            with open(log_path, 'r') as f:
                recent_logs = f.readlines()[-50:]
            if any(any(key in line for key in risk_keywords) for line in recent_logs):
                return 1
        except Exception:
            continue

    return 0

def get_disk_stats(domain):
    try:
        # Use 'vda' as found in your domblklist
        stats = domain.blockStats('vda')
        return stats[1], stats[3]  # Returns read_bytes, write_bytes
    except Exception as e:
        print(f"Disk Error: {e}")
        return 0, 0

def get_proc_count():
    # Counts only the folders named with numbers (which are PIDs)
    return len([d for d in os.listdir('/proc') if d.isdigit()])

def get_cpu_usage(domain):
    try:
        cpu_stats = domain.getCPUStats(True)
        return cpu_stats[0]['cpu_time']  # nanoseconds
    except Exception as e:
        print(f"CPU Error: {e}")
        return 0

# Connect to the local KVM hypervisor
try:
    # Use System because your virsh commands worked there
    conn = libvirt.open("qemu:///system")
    domain = conn.lookupByName('victim-vm')
except Exception as e:
    print(f"Connection Error: {e}")
    sys.exit(1)

data_log = []
prev_read, prev_write = get_disk_stats(domain)
prev_cpu = get_cpu_usage(domain)
prev_time = time.time()

print(f"--- Monitoring {VM_NAME} ---")
print(f"Output file: {OUTPUT_FILE}")
print(f"Label value: {LABEL_VALUE}")
print("Press Ctrl+C to stop and save...")

try:
    while True:
        curr_time = time.time()
        curr_read, curr_write = get_disk_stats(domain)
        curr_cpu = get_cpu_usage(domain)
        dt = curr_time - prev_time
        if dt <= 0:
            time.sleep(1)
            continue
        
        # CALCULATE THE CHANGES
        read_delta = curr_read - prev_read
        write_delta = curr_write - prev_write
        cpu_delta = curr_cpu - prev_cpu
        cpu_usage = cpu_delta / (dt * 1e9)
        proc_count = get_proc_count()
        
        # SAVE TO DATA LOG
        data_log.append({
            'Timestamp': curr_time,
            'CPU_Usage': cpu_usage,
            'Read_Delta': read_delta,
            'Write_Delta': write_delta,
            'Proc_Count': proc_count,
            'Label': LABEL_VALUE
        })
        
        # UPDATE PREVIOUS FOR NEXT SECOND
        prev_read, prev_write = curr_read, curr_write
        prev_cpu = curr_cpu
        prev_time = curr_time
        
        time.sleep(1) # Record every second
except KeyboardInterrupt:
    df = pd.DataFrame(data_log)
    if not df.empty:
        df['Label'] = LABEL_VALUE

    if df.empty:
        print("\nNo data captured; nothing written.")
    else:
        file_exists = os.path.exists(OUTPUT_FILE)
        df.to_csv(OUTPUT_FILE, mode='a', header=not file_exists, index=False)
        print(f"\nAppended {len(df)} rows to {OUTPUT_FILE}")

