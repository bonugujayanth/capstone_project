import pandas as pd
import lightgbm as lgb
import joblib
import warnings

warnings.filterwarnings('ignore')

print("Loading combine.csv...")
df = pd.read_csv('combine.csv', on_bad_lines='skip', comment='#')
if 'Label' not in df.columns:
    df = pd.read_csv('combine.csv', header=None, on_bad_lines='skip', comment='#')
    if len(df.columns) >= 6:
        df.columns = ['Timestamp', 'CPU_Usage', 'Read_Delta', 'Write_Delta', 'Proc_Count', 'Label'] + list(df.columns[6:])

for col in ['Timestamp', 'CPU_Usage', 'Read_Delta', 'Write_Delta', 'Proc_Count', 'Label']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

df = df.dropna(subset=['Timestamp', 'Label']).reset_index(drop=True)
df = df.ffill().fillna(0)

X = df[['CPU_Usage', 'Read_Delta', 'Write_Delta']]
y = df['Label'].astype(int)

print("Training standard LightGBM model without noise on combine.csv dataset...")
model = lgb.LGBMClassifier(
    n_estimators=150,
    learning_rate=0.05,
    max_depth=5,
    random_state=42,
    verbose=-1,
    n_jobs=-1
)
model.fit(X, y)

model_path = 'ransomware_detector.pkl'
joblib.dump(model, model_path)
print(f"Model successfully saved to {model_path}")
