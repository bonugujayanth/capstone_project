import pandas as pd
import joblib
from sklearn.metrics import confusion_matrix, classification_report
import os
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

file_path = 'combine.csv'
model_path = 'ransomware_detector.pkl'

print("=== Evaluating Model on combine.csv ===")

# If combine.csv is empty or missing, generate it automatically
if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
    print(f"'{file_path}' is empty. Automatically generating it from benign and malware datasets...")
    df_benign = pd.read_csv('benign_extended_updated.csv', on_bad_lines='skip', comment='#')
    df_malware = pd.read_csv('malware_extended_updated.csv', on_bad_lines='skip', comment='#')
    df_combined = pd.concat([df_benign, df_malware], ignore_index=True)
    df_combined.to_csv(file_path, index=False)
    print(f"Successfully generated {file_path} with {len(df_combined)} rows.")

print(f"Loading LightGBM model from {model_path}...")
model = joblib.load(model_path)

print(f"Reading data from {file_path}...")
# Skip bad lines and comments just like in training
df = pd.read_csv(file_path, on_bad_lines='skip', comment='#')

# If headers are missing, assign them manually
if 'Label' not in df.columns:
    df = pd.read_csv(file_path, header=None, on_bad_lines='skip', comment='#')
    if len(df.columns) >= 6:
        df.columns = ['Timestamp', 'CPU_Usage', 'Read_Delta', 'Write_Delta', 'Proc_Count', 'Label'] + list(df.columns[6:])
    else:
        print("Error: Columns mismatch in combine.csv. Expected 6 columns.")
        exit(1)

# Enforce numeric types
for col in ['Timestamp', 'CPU_Usage', 'Read_Delta', 'Write_Delta', 'Proc_Count', 'Label']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Drop invalid rows and fill NaNs
df = df.dropna(subset=['Timestamp', 'Label']).reset_index(drop=True)
df = df.ffill().fillna(0)

# Extract features and target
X = df[['CPU_Usage', 'Read_Delta', 'Write_Delta']]
y = df['Label'].astype(int)

print(f"\nTotal valid samples processed: {len(df)}")
print("Running inference...")
y_pred = model.predict(X)

print("\n--- Results ---")
print("Confusion Matrix:")
print(confusion_matrix(y, y_pred))

print("\nClassification Report:")
print(classification_report(y, y_pred, target_names=["Benign (0)", "Ransomware (1)"], digits=4))
