import libvirt
import time
import pandas as pd
import sys
import os
import joblib
import warnings

warnings.filterwarnings('ignore')

# CONFIGURATION
MODEL_PATH = os.path.join(os.path.dirname(__file__), "ransomware_detector.pkl")

def get_mgmt_alert():
    log_paths = [
        "/var/log/libvirt/qemu/victim-vm.log",
        os.path.expanduser("~/.local/share/libvirt/qemu/log/victim-vm.log"),
    ]

    risk_keywords = [
        "device_del",
        "snapshot-delete",
        "set_password",
        "drive-del",
        "blockdev-del",
        "netdev_del",
        "block-job-cancel",
        "block-job-pause",
        "send-key",
    ]

    for log_path in log_paths:
        if not os.path.exists(log_path):
            continue
        try:
            with open(log_path, 'r') as f:
                recent_logs = f.readlines()[-50:]
            if any(any(key in line for key in risk_keywords) for line in recent_logs):
                return 1
        except Exception:
            continue

    return 0

def get_disk_stats(domain):
    try:
        # Use 'vda' as found in your domblklist
        stats = domain.blockStats('vda')
        return stats[1], stats[3]  # Returns read_bytes, write_bytes
    except Exception as e:
        print(f"Disk Error: {e}")
        return 0, 0

def get_proc_count():
    # Counts only the folders named with numbers (which are PIDs)
    return len([d for d in os.listdir('/proc') if d.isdigit()])

def get_cpu_usage(domain):
    try:
        cpu_stats = domain.getCPUStats(True)
        return cpu_stats[0]['cpu_time']  # nanoseconds
    except Exception as e:
        print(f"CPU Error: {e}")
        return 0

def main():
    print("Loading pre-trained model...")
    try:
        model = joblib.load(MODEL_PATH)
    except Exception as e:
        print(f"Error loading model: {e}")
        sys.exit(1)

    print("Connecting to local KVM hypervisor...")
    try:
        # Use System because your virsh commands worked there
        conn = libvirt.open("qemu:///system")
    except Exception as e:
        print(f"Connection Error: {e}")
        sys.exit(1)

    vm_states = {}

    print("--- Starting Real-Time Ransomware Monitoring ---")
    print("Press Ctrl+C to stop...")

    try:
        while True:
            # Module 1: Multi-VM Context Handling
            active_domains = conn.listAllDomains(libvirt.VIR_CONNECT_LIST_DOMAINS_ACTIVE)
            current_uuids = set()

            for domain in active_domains:
                try:
                    uuid = domain.UUIDString()
                    name = domain.name()
                    current_uuids.add(uuid)

                    curr_time = time.time()
                    curr_read, curr_write = get_disk_stats(domain)
                    curr_cpu = get_cpu_usage(domain)
                    proc_count = get_proc_count()

                    if uuid not in vm_states:
                        vm_states[uuid] = {
                            'prev_time': curr_time,
                            'prev_read': curr_read,
                            'prev_write': curr_write,
                            'prev_cpu': curr_cpu
                        }
                        continue

                    prev_state = vm_states[uuid]
                    dt = curr_time - prev_state['prev_time']

                    if dt <= 0:
                        continue

                    # Calculate the Deltas for the 1-second interval
                    read_delta = curr_read - prev_state['prev_read']
                    write_delta = curr_write - prev_state['prev_write']
                    cpu_delta = curr_cpu - prev_state['prev_cpu']

                    # Module 2 & 3: Live Pipeline calculations
                    # Normalized CPU usage (Δns/10^9)
                    cpu_usage = cpu_delta / (dt * 1e9)
                    
                    # Disk MB/s (calculated for logging/verification, but model expects bytes as 'Read_Delta' and 'Write_Delta')
                    read_mbps = (read_delta / dt) / (1024 * 1024)
                    write_mbps = (write_delta / dt) / (1024 * 1024)

                    features = pd.DataFrame([{
                        'CPU_Usage': cpu_usage,
                        'Read_Delta': read_delta, # Passing bytes as expected by the trained LightGBM model
                        'Write_Delta': write_delta # Passing bytes as expected by the trained LightGBM model
                    }])

                    # Pass features into model
                    proba = model.predict_proba(features)[0][1]

                    # Module 4: Detection Logic
                    metrics_str = f"[CPU: {cpu_usage:.2f} | Read: {read_mbps:.2f} MB/s | Write: {write_mbps:.2f} MB/s]"
                    if proba > 0.85:
                        print(f"[ALERT] Malware Found in VM: {name} (Confidence: {proba:.4f}) {metrics_str}")
                    else:
                        print(f"[STATUS] VM: {name} - Healthy ({proba:.4f}) {metrics_str}")

                    # Update 'Previous State' for the next iteration
                    vm_states[uuid] = {
                        'prev_time': curr_time,
                        'prev_read': curr_read,
                        'prev_write': curr_write,
                        'prev_cpu': curr_cpu
                    }

                except libvirt.libvirtError:
                    # VM might have been shut down during the loop iteration
                    pass
                except Exception as e:
                    print(f"Error processing VM {domain.name() if hasattr(domain, 'name') else 'Unknown'}: {e}")

            # Error Handling: gracefully remove VMs that were suddenly shut down
            uuids_to_remove = [u for u in vm_states if u not in current_uuids]
            for u in uuids_to_remove:
                del vm_states[u]

            time.sleep(1)

    except KeyboardInterrupt:
        print("\nMonitoring stopped by user. Exiting...")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
